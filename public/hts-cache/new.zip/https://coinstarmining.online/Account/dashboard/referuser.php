<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="uVfTiF4siYbSic8FKD2VYmWG6NbepdVao1ZCDC8A">
    <title>coinstarmining | Refer Users</title>
    <link rel="icon" href="https://coinstarmining.online/cloud/app/images/ahwg.jpg" type="image/png" />
    <!-- Fonts and icons -->
    <script src="../dash/js/plugin/webfont/webfont.min.js"></script>
    <!-- Sweet Alert -->
    <script src="../dash/js/plugin/sweetalert/sweetalert.min.js "></script>
    <!-- CSS Files -->
    <link rel="stylesheet" href="../dash/css/bootstrap.min.css">
    <link rel="stylesheet" href="../dash/css/fonts.min.css">
    <link rel="stylesheet" href="../dash/css/atlantis.min.css">
    <link rel="stylesheet" href="../dash/css/customs.css">
    <link rel="stylesheet" href="../dash/css/style.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/dt-1.10.21/af-2.3.5/b-1.6.3/b-flash-1.6.3/b-html5-1.6.3/b-print-1.6.3/r-2.2.5/datatables.min.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
</head>

<body data-background-color="dark">
    <div id="app">
        <!--PayPal-->
        <script>
        // Add your client ID and secret
        var PAYPAL_CLIENT = 'AVBtU3h5-r3jo4RQdreB1k1oceT9fUNzJRcCtiST9TtVrEfYBVIGLf_5Ew3NJ0XMQiJ_l3Us3Br9fnmi';
        var PAYPAL_SECRET = 'EOFG7L81QhUKSoBlIYacAaI-0CplcXnf2n-nDZ9j6xyj3zOFTpVbhoitbvlcqSELx5RYbsQ12sxw3ZOd';

        // Point your server to the PayPal API
        var PAYPAL_ORDER_API = 'https://api.paypal.com/v2/checkout/orders/';
        </script>
        <script src="https://www.paypal.com/sdk/js?client-id=AVBtU3h5-r3jo4RQdreB1k1oceT9fUNzJRcCtiST9TtVrEfYBVIGLf_5Ew3NJ0XMQiJ_l3Us3Br9fnmi">
        </script>
        <!--/PayPal-->
        <!--Start of Tawk.to Script-->
        <script type="text/javascript">
        {}
        </script>
        <!--End of Tawk.to Script-->
        <div class="wrapper">
            <div class="main-header">
                <!-- Logo Header -->
                <div class="logo-header" data-background-color="dark">
                    <a href="/" class="logo" style="font-size: 27px; color:#fff;">
                        coinstarmining
                    </a>
                    <button class="navbar-toggler sidenav-toggler ml-auto" type="button" data-toggle="collapse" data-target="collapse" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon">
                            <i class="icon-menu"></i>
                        </span>
                    </button>
                    <button class="topbar-toggler more"><i class="icon-options-vertical"></i></button>
                    <div class="nav-toggle">
                        <button class="btn btn-toggle toggle-sidebar">
                            <i class="icon-menu"></i>
                        </button>
                    </div>
                </div>
                <!-- End Logo Header -->
                <!-- Navbar Header -->
                <nav class="navbar navbar-header navbar-expand-lg" data-background-color="dark">
                    <div class="container-fluid">
                        <ul class="navbar-nav topbar-nav ml-md-auto align-items-center">
                            <li class="nav-item dropdown hidden-caret">
                                <a class="nav-link dropdown-toggle" href="#" id="notifDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="fa fa-bell"></i>
                                </a>
                                <ul class="dropdown-menu notif-box animated fadeIn" aria-labelledby="notifDropdown">
                                    <li>
                                        <a class="see-all" href="../dashboard/notification">See all notifications<i class="fa fa-angle-right"></i> </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="nav-item dropdown hidden-caret">
                                <a class="nav-link" data-toggle="dropdown" href="#" aria-expanded="false">
                                    <i class="fas fa-user"></i>
                                </a>
                                <ul class="dropdown-menu dropdown-user animated fadeIn">
                                    <div class="dropdown-user-scroll scrollbar-outer">
                                        <li>
                                            <a class="dropdown-item" href="../dashboard/changepassword">Change Password</a>
                                            <a class="dropdown-item" href="../dashboard/profile">Update Account</a>
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item" href="../logout.php" onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();">
                                                Logout
                                            </a>
                                            <form id="logout-form" action="../logout" method="POST" style="display: none;">
                                                <input type="hidden" name="_token" value="uVfTiF4siYbSic8FKD2VYmWG6NbepdVao1ZCDC8A">
                                            </form>
                                        </li>
                                    </div>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </nav>
                <!-- End Navbar -->
            </div> <!-- Stored in resources/views/child.blade.php -->
            <!-- Sidebar -->
          

<div class="sidebar sidebar-style-2" data-background-color="dark">
    <div class="sidebar-wrapper scrollbar scrollbar-inner">
        <div class="sidebar-content">
            <div class="user">
                <div class="info">
                    <a data-toggle="collapse" href="#collapseExample" aria-expanded="true">
                        
                    </a>
                    <div class="clearfix"></div>
                    <div class="collapse in" id="collapseExample">
                        <ul class="nav">
                            <li>
                                <a href="../dashboard/profile.php">
                                    <span class="link-collapse">Account Settings</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <ul class="nav nav-primary">
                <li class="nav-item active">
                    <a href="../dashboard.php">
                        <i class="fas fa-home"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a data-toggle="collapse" href="#bases">
                        <i class="fas fa-user"></i>
                        <p>Account</p>
                        <span class="caret"></span>
                    </a>
                    <div class="collapse" id="bases">
                        <ul class="nav nav-collapse">
                            <li>
                                <a href="../dashboard/accountdetails.php">
                                    <span class="sub-item">Withdrawal Info</span>
                                </a>
                            </li>
                            <li>
                                <a href="../dashboard/notification.php">
                                    <span class="sub-item">Notifications</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>
                <li class="nav-item">
                    <a href="../dashboard/support.php">
                        <i class="fa fa-life-ring" aria-hidden="true"></i>
                        <p>Support</p>
                    </a>
                </li>
              
                <li class="nav-item">
                    <a href="../dashboard/accounthistory.php">
                        <i class="fa fa-briefcase " aria-hidden="true"></i>
                        <p>Transactions history</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a data-toggle="collapse" href="#dept">
                        <i class="fas fa-credit-card"></i>
                        <p>Deposit/Withdrawal</p>
                        <span class="caret"></span>
                    </a>
                    <div class="collapse" id="dept">
                        <ul class="nav nav-collapse">
                            <li>
                                <a href="../dashboard/deposits.php">
                                    <span class="sub-item">Deposits</span>
                                </a>
                            </li>
                            <li>
                                <a href="../dashboard/withdrawals.php">
                                    <span class="sub-item">Withdrawal</span>
                                </a>
                            </li>
                        </ul>
                    </div>
               
                </li>
                <li class="nav-item">
                    <a data-toggle="collapse" href="#mpack">
                        <i class="fas fa-cubes"></i>
                        <p>Packages</p>
                        <span class="caret"></span>
                    </a>
                    <div class="collapse" id="mpack">
                        <ul class="nav nav-collapse">
                            <li>
                                <a href="../dashboard/mplans.php">
                                    <span class="sub-item">Investment Plans</span>
                                </a>
                            </li>
                            
                        </ul>
                    </div>
                </li>  
                <li class="nav-item">
                    <a href="../dashboard/referuser.php">
                        <i class="fa fa-recycle " aria-hidden="true"></i>
                        <p>Refer Users</p>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>
            <!-- End Sidebar -->
            <!-- Verify Modal -->
            <div class="modal fade" id="verifyModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header bg-dark">
                            <h5 class="modal-title text-light" style="text-align:center;">KYC verification - Upload documents below to get verified.</h5>
                            <button type="button" class="close text-light" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body bg-dark">
                            <form style="padding:3px;" role="form" method="post" action="../dashboard/savevdocs" enctype="multipart/form-data">
                                <label class="text-light">Valid identity card. (e.g. Drivers licence, international passport or any government approved document).</label>
                                <input type="file" class="form-control bg-dark text-light" name="id" required><br>
                                <label class="text-light">Passport photogragh</label>
                                <input type="file" class="form-control bg-dark text-light" name="passport" required><br>
                                <input type="hidden" name="_token" value="uVfTiF4siYbSic8FKD2VYmWG6NbepdVao1ZCDC8A">
                                <input type="submit" class="btn btn-light" value="Submit documents">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /Verify Modal -->
            <div class="main-panel bg-dark">
                <div class="content bg-dark">
                    <div class="page-inner">
                        <div class="mt-2 mb-4">
                            <h1 class="title1 text-light">Refer users to coinstarmining community</h1>
                        </div>
                        <div class="row">
                            <div class="col-12 text-center card bg-dark shadow-lg p-3 text-light">
                                <strong>You can refer users by sharing your referral link:</strong><br>
                                <h4 style="color:green;"> https://coinstarmining.online/ref/1606</h4> <br>
                                <h3 class="title1">
                                    <small>Your sponsor</small><br>
                                    <i class="fa fa-user fa-2x"></i><br>
                                    <small>null</small>
                                </h3>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col card p-3 shadow-lg bg-dark">
                                <h2 class="title1 text-light">Your Referrals.</h2>
                                <div class="bs-example widget-shadow table-responsive" data-example-id="hoverable-table">
                                    <table class="table UserTable table-hover text-light">
                                        <thead>
                                            <tr>
                                                <th>Client name</th>
                                                <th>Ref. level</th>
                                                <th>Parent</th>
                                                <th>Client status</th>
                                                <th>Date registered</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <footer class="footer bg-dark text-light">
                    <div class="container-fluid">
                        <div class="row copyright text-center text-align-center">
                            <p>All Rights Reserved &copy; coinstarmining 2021</p>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
    </div>
    <!--   Core JS Files   -->
    <script src="../dash/js/core/jquery.3.2.1.min.js "></script>
    <script src="../dash/js/core/popper.min.js"></script>
    <script src="../dash/js/core/bootstrap.min.js "></script>
    <script src="../dash/js/customs.js"></script>
    <!-- jQuery UI -->
    <script src="../dash/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
    <script src="../dash/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>
    <!-- jQuery Scrollbar -->
    <script src="../dash/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js "></script>
    <!-- jQuery Sparkline -->
    <script src="../dash/js/plugin/jquery.sparkline/jquery.sparkline.min.js "></script>
    <!-- Sweet Alert -->
    <script src="../dash/js/plugin/sweetalert/sweetalert.min.js "></script>
    <!-- Bootstrap Notify -->
    <script src="../dash/js/plugin/bootstrap-notify/bootstrap-notify.min.js "></script>
    <script type="text/javascript" src="https://cdn.datatables.net/v/bs4/dt-1.10.21/af-2.3.5/b-1.6.3/b-flash-1.6.3/b-html5-1.6.3/b-print-1.6.3/r-2.2.5/datatables.min.js"></script>
    <!-- Atlantis JS -->
    <script src="../dash/js/atlantis.min.js"></script>
    <script src="../dash/js/atlantis.js"></script>
    <script type="text/javascript">
    var badWords = [
        '<!--Start of Tawk.to Script-->',
        '<script type="text/javascript">',
        '<!--End of Tawk.to Script-->'
    ];
    $(':input').on('blur', function() {
        var value = $(this).val();
        $.each(badWords, function(idx, word) {
            value = value.replace(word, '');
        });
        $(this).val(value);
    });
    </script>
    <script>
    $(document).ready(function() {
        $('#ShipTable').DataTable({
            order: [
                [0, 'desc']
            ]
        });
        $(".dataTables_length select").addClass("bg-dark text-light");
        $(".dataTables_filter input").addClass("bg-dark text-light");
    });
    </script>
    <script>
    $(document).ready(function() {
        $('.UserTable').DataTable({
            order: [
                [0, 'desc']
            ]
        });
        $(".dataTables_length select").addClass("bg-dark text-light");
        $(".dataTables_filter input").addClass("bg-dark text-light");
    });
    </script>
</body>

</html>